To compile the code type in "gcc -g --std=gnu99 -o movies_by_year assignment2.c"
This will create an executable file named movies_by_year in which to run the program type "./movies_by_year"
To run with gdb type in "gdb ./movies_by_year" 
To run with valgrind with all its flags type in "valgrind --leak-check=full --track-origins=yes ./movies_by_year"
